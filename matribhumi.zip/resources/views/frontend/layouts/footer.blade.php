 <footer>
      <div class="container">
          <div class="footer-wrap relative clearfix">
              <div class="row row-flex-wrap row-flex">
                <div class="col-sm-6 col-md-3">
                  <div class="f-widget f-menu flex-col">
                      <h3 class="font24px text-blue weight-700 mt-0 mb-20">
                        सम्पर्क ठेगाना 
                      </h3>
                      <ul class="font20px">
                          <li>मातृभूमि संचार नेटवर्क</li>
                          <li>ठेगाना :  सुमार्गी बी कम्प्लेक्स, बबरमहल- ११, काठमाडौं, नेपाल</li>
                          <li>सम्पर्क :   +९७७-१- ४२६१९४१</li>
                          <li>बिज्ञापन सम्पर्क :   ९७७-१-४२६३४५४, ९८५१०७६३३६ (सञ्जय नेपाल)</li>
                          <li>समाचार विभाग इमेल:   matribhumisandesh2074@gmail.com</li>
                          <li>ईमेल :   matribhumisandesh2074@gmail.com</li>
                      </ul>
                  </div>
                </div>
                <div class="col-sm-6 col-md-3">
                  <div class="f-widget f-menu flex-col">
                      <h3 class="font24px text-blue weight-700 mt-0 mb-20">
                          लिङ्कहरू 
                      </h3>
                      <ul class="font20px">
                          <li><a href="">अन्तर्वार्ता</a></li>
                          <li><a href="">कला</a></li>
                          <li><a href="">खेलकुद</a></li>
                          <li><a href="">पैसा</a></li>
                          <li><a href="">प्रवास</a></li>
                          <li><a href="">भिडियो</a></li>
                          <li><a href="">मनोरञ्जन</a></li>
                      </ul>
                  </div>
                </div>
                <div class="col-sm-6 col-md-3">
                  <div class="f-widget f-menu flex-col">
                      <h3 class="font24px text-blue weight-700 mt-0 mb-20">
                          लिङ्कहरू 
                      </h3>
                      <ul class="font20px">
                          <li><a href="">अन्तर्वार्ता</a></li>
                          <li><a href="">कला</a></li>
                          <li><a href="">खेलकुद</a></li>
                          <li><a href="">पैसा</a></li>
                          <li><a href="">प्रवास</a></li>
                          <li><a href="">भिडियो</a></li>
                          <li><a href="">मनोरञ्जन</a></li>
                      </ul>
                  </div>
                </div>
                <div class="col-sm-6 col-md-3">
                  <div class="f-widget f-menu flex-col">
                      <h3 class="font24px text-blue weight-700 mt-0 mb-20">
                          लिङ्कहरू 
                      </h3>
                      <ul class="font20px">
                          <li><a href="">अन्तर्वार्ता</a></li>
                          <li><a href="">कला</a></li>
                          <li><a href="">खेलकुद</a></li>
                          <li><a href="">पैसा</a></li>
                          <li><a href="">प्रवास</a></li>
                          <li><a href="">भिडियो</a></li>
                          <li><a href="">मनोरञ्जन</a></li>
                      </ul>
                  </div>
                </div>
              </div>
              <!-- <div class="notification-icon">
                <a href=""  class="notification-bell"><i class="fa fa-bell-o"></i></a>
              </div> -->
              <!-- <div class="to-top">
                <a href="#" onclick="topFunction()" id="myBtn" title="Go to top">
                  <img src="assets/images/to-top.png">
                </a>
              </div> -->
          </div>
      </div>

       <div class="footer-last">
          <div class="container">
              <div class="footer-last-wrap">
                <div class="row">
                    <div class="col-sm-4 col-md-3">
                      <img src="assets/images/Asset-10.png" alt="" width="306px" class="img-responsive">
                    </div>
                    <div class="col-sm-4 col-md-2">
                       <a href="">अध्यक्ष तथा प्रबन्ध निर्देशक:<br>धर्मराज भुसाल</a>
                    </div>
                    <div class="col-sm-4 col-md-2">
                       <a href="">प्रधान सम्पादकः</br>शिव गाउँले</a>
                    </div>
                    <div class="col-sm-4 col-md-2">
                       <a href="">सूचना विभाग दर्ता नं.<br>२१४ / ०७३–७४</a>
                    </div>
                    <div class="col-sm-4 col-md-3 text-center">
                      <div class="ok-social-brands">
                          <a href=#"><i class="fa fa-facebook-f"></i></a>
                          <a href="#"><i class="fa fa-twitter"></i></a>
                          <a href="#"><i class="fa fa-youtube"></i></a>
                      </div>
                      © २००६-२०२२ सर्वाधिकार सुरक्षित
                    </div>
                    
                </div>
              </div>
          </div>
      </div>
  </footer>

  <!-- Jquery Library -->
  <script type="text/javascript" src="{{ asset('assets/js/library.min.js') }}"></script>

  <!-- Bootstrap -->
  <script type="text/javascript" src="{{ asset('assets/js/bootstrap.min.js') }}"></script>

  <!-- Scrollbar -->
  <script type="text/javascript" src="{{ asset('assets/js/scrollbar.js') }}"></script>

  <!-- Custom -->
  <script type="text/javascript" src="{{ asset('assets/js/custom.js') }}"></script>
</body>
</html>