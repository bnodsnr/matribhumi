
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb breadcrumb-custom">
        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
        <li class="breadcrumb-item active" aria-current="page"><span>Videos</span></span></li>
      </ol>
    </nav>
    <div class="card">

      <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
      </div>
      <?php endif; ?>
      <div class="table-responsive">
        <div class="  ">
        <a class="btn btn-sm btn-dark" href="#frmadd" data-toggle="modal" data-url="<?php echo e(route('create-videos')); ?>" data-id=""><i class="fa fa-plus-circle"></i> Add New</a>
      </div><br>
        <table class="rtable">
          <thead>
            <tr>
              <th>SN</th>
              <th>Videos</th>
              <th>Headline</th>
              <th>Is Feature?</th>
              <th>Status</th>
              <th>#</th>
            </tr>
          </thead>
          <tbody>
            <?php if(!empty($videos)): ?>
            <?php $i=1; ?>
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $videos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $video_id = explode("?v=", $videos->url);
            $video_id = !empty($video_id[1]) ? $video_id[1]:'';
            $thumbnail="http://img.youtube.com/vi/".$video_id."/maxresdefault.jpg";
            ?>
            <tr>
              <td><?php echo e($i++); ?></td>
              <td><a href="<?php echo e($videos->url); ?>" target = "_blank"><img src = "<?php echo e($thumbnail); ?>" style="width:100px;height:100px"></a></td>
              <td><?php echo e($videos->headline); ?></td>
              <td><span class ="badge badge-<?php echo e($videos->is_feature == 1 ? 'warning':'danger'); ?>"><?php echo e($videos->is_feature == 1? 'yes':'no'); ?></span></td>
              <td><span class ="badge badge-<?php echo e($videos->status == 1 ? 'success':'danger'); ?>"><?php echo e($videos->status == 1? 'publish':''); ?></span></td>
              <td>
                <a class="btn btn-sm btn-info" href="#frmedit" data-toggle="modal" data-url="<?php echo e(route('edit-videos')); ?>" data-id="<?php echo e($videos->id); ?>">
                  <i class="fa fa-pencil"></i>
                </a>
                <a class="btn btn-sm btn-danger" href="<?php echo e(route('delete-videos', $videos->id)); ?>">
                  <i class="fa fa-trash"></i>
                </a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>
<!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matribhumi\resources\views/videos/list.blade.php ENDPATH**/ ?>