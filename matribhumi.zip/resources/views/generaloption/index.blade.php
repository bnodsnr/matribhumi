@extends('layouts.master')
@section('content')
<div class="row">
  <div class="col-lg-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb bg-danger">
        <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
        <li class="breadcrumb-item active" aria-current="page">General Option</li>
      </ol>
    </nav>
    <div class="card">
      <div class="card-body">
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home-1" role="tab" aria-controls="home-1" aria-selected="true"> <i class="fa fa-navicon"></i> Header Menu</a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile-1" role="tab" aria-controls="profile-1" aria-selected="false"><i class="fa fa-navicon"></i> Category</a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false"><i class="fa fa-address-book"></i> Address Book</a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact-1" role="tab" aria-controls="contact-1" aria-selected="false">Footer Menu</a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact-1" role="tab" aria-controls="contact-1" aria-selected="false"><i class="fa fa-facebook-square"></i> Social Media</a>
          </li>
        </ul>  
        <!-- Menu Settin -->
        <div class="tab-pane fade active" id="home-1" role="tabpanel" aria-labelledby="home-tab">
          <div class="card-body">
            <h4 class="card-title"><i class="fa fa-cogs"></i> Header Menu</h4>
            <div class="row">
              <div class="col-md-12 h-100">
                <div class="p-4">
                  <div id="dragula-right" class="py-2">
                    @if(!empty($menus))
                    @foreach($menus as $menu)
                    <div class="card rounded border mb-2">
                      <div class="card-body p-3">
                        <div class="media">
                          <i class="mdi mdi-apps icon-sm text-success align-self-center mr-3"></i>
                          <div class="media-body">
                            <h6 class="mb-1"><input type="hidden" name="menu_position" value="">{{ $menu->category_name }}</h6>
                            <!-- <p class="mb-0 text-muted">
                              Get new project details from Greg                               
                            </p> -->
                          </div>                              
                        </div> 
                      </div>
                    </div>
                    @endforeach
                    @endif
                    <!-- <div class="card rounded border mb-2">
                      <div class="card-body p-3">
                        <div class="media">
                          <i class="mdi mdi-apps icon-sm align-self-center mr-3"></i>
                          <div class="media-body">
                            <h6 class="mb-1">Leave approval</h6>
                            <p class="mb-0 text-muted">
                              Approve leaves for Mike                           
                            </p>
                          </div>                              
                        </div> 
                      </div>
                    </div>
                    <div class="card rounded border mb-2">
                      <div class="card-body p-3">
                        <div class="media">
                          <i class="mdi mdi-bank icon-sm align-self-center mr-3"></i>
                          <div class="media-body">
                            <h6 class="mb-1">Make reservations at hotel</h6>
                            <p class="mb-0 text-muted">
                              Book rooms for vacation                             
                            </p>
                          </div>                              
                        </div> 
                      </div>
                    </div>
                    <div class="card rounded border mb-2">
                      <div class="card-body p-3">
                        <div class="media">
                          <i class="mdi mdi-calendar icon-sm align-self-center mr-3"></i>
                          <div class="media-body">
                            <h6 class="mb-1">Meeting with client</h6>
                            <p class="mb-0 text-muted">
                              New project meeting                              
                            </p>
                          </div>                              
                        </div> 
                      </div>
                    </div> -->

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--  menu seting ends-->

        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
          <div class="card-body">
                  <h4 class="card-title">Basic input groups</h4>
                  <p class="card-description">
                    Basic bootstrap input groups
                  </p>
                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">@</span>
                      </div>
                      <input type="text" class="form-control" placeholder="Username" aria-label="Username">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text bg-primary text-white">$</span>
                      </div>
                      <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)">
                      <div class="input-group-append">
                        <span class="input-group-text">.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">$</span>
                      </div>
                      <div class="input-group-prepend">
                        <span class="input-group-text">0.00</span>
                      </div>
                      <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username">
                      <div class="input-group-append">
                        <button class="btn btn-sm btn-primary" type="button">Search</button>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</button>
                        <div class="dropdown-menu">
                          <a class="dropdown-item" href="#">Action</a>
                          <a class="dropdown-item" href="#">Another action</a>
                          <a class="dropdown-item" href="#">Something else here</a>
                          <div role="separator" class="dropdown-divider"></div>
                          <a class="dropdown-item" href="#">Separated link</a>
                        </div>
                      </div>
                      <input type="text" class="form-control" aria-label="Text input with dropdown button">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="Find in facebook" aria-label="Recipient's username">
                      <div class="input-group-append">
                        <button class="btn btn-sm btn-facebook" type="button">
                          <i class="mdi mdi-facebook"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
        </div>
        <div class="tab-pane fade" id="contact--1" role="tabpanel" aria-labelledby="">
          <h4>Contact us </h4>
          <p>
            Feel free to contact us if you have any questions!
          </p>
          <p>
            <i class="mdi mdi-phone text-info"></i>
            +123456789
          </p>
          <p>
            <i class="mdi mdi-email-outline text-success"></i>
            contactus@example.com
          </p>
        </div>
      </div>`
      </div>
    </div>
  </div>
</div>
</div>

<script>
  (function($) {
  'use strict';
  var iconTochange;
  // dragula([document.getElementById("dragula-left"), document.getElementById("dragula-right")]);
  // dragula([document.getElementById("profile-list-left"), document.getElementById("profile-list-right")]);
  // dragula([document.getElementById("dragula-right"), document.getElementById("dragula-right")])
  //   .on('drag', function(el) {
      // console.log($(el));
      // iconTochange = $(el).find('.mdi');
      // if (iconTochange.hasClass('mdi-check')) {
      //   iconTochange.removeClass('mdi-check text-primary').addClass('mdi-check-all text-success');
      // } else if (iconTochange.hasClass('mdi-check-all')) {
      //   iconTochange.removeClass('mdi-check-all text-success').addClass('mdi-check text-primary');
      // }
    })
//})(jQuery);
</script>
<!-- content-wrapper ends -->
@endsection