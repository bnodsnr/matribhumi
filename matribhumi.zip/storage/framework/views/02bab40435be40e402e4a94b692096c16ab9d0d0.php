  <nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item">
        <a class="navbar-brand brand-logo-mini" href="#" style="color:#fff"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" style="width:175px;" /> </a>
        <a class="navbar-brand brand-logo" href="#" style="color:#fff"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" style="width:175px;" /> </a>
      </li>
      <li class="nav-item">
        <hr>
      </li>
      <li class="nav-item">
        <a class="nav-link font-weight-bold active" href="#">
          <i class="fa fa-tachometer"></i>&nbsp;Dashboard 
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link font-weight-bold active" href="<?php echo e(route('category')); ?>">
        <i class="fa fa-camera"></i>&nbsp;Categories
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link font-weight-bold active" href="<?php echo e(route('dashboard')); ?>">
        <i class="fa fa-file-powerpoint-o"></i>&nbsp;Pages
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link font-weight-bold active" href="<?php echo e(route('news')); ?>">
        <i class="fa fa-tasks"></i>&nbsp;News Management
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link font-weight-bold active" href="<?php echo e(route('manage-ads')); ?>">
        <i class="fa fa-audio-description"></i>&nbsp;Advertisement
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link font-weight-bold active" href="<?php echo e(route('videos')); ?>">
        <i class="fa fa-video-camera"></i>&nbsp;Videos
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link font-weight-bold active" href="<?php echo e(route('dashboard')); ?>">
        <i class="fa fa-comments"></i>&nbsp;Comments
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link font-weight-bold active" href="<?php echo e(route('general-option')); ?>">
        <i class="fa fa-sliders"></i>&nbsp;General Option
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link font-weight-bold active" href="<?php echo e(route('dashboard')); ?>">
        <i class="fa fa-cog"></i>&nbsp;General Setting
        </a>
      </li>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-user')): ?>
      <li class="nav-item">
        <a class="nav-link font-weight-bold" data-toggle="collapse" href="#pages" aria-expanded="false" aria-controls="pages">
          <i class="fa fa-users"></i>&nbsp;Users
          &nbsp;<i class="fa fa-angle-down"></i>
        </a>
        <div class="collapse" id="pages">
          <ul class="nav flex-column sub-menu">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-role')): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(URL :: to('/roles')); ?>"><i class="fa fa-hand-o-right"></i>&nbsp; Role </a></li>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-permission')): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('modules')); ?>"><i class="fa fa-hand-o-right"></i>&nbsp; Permission </a></li>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-user')): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(URL :: to('/users')); ?>"> <i class="fa fa-hand-o-right"></i>&nbsp; Users </a></li>
          <?php endif; ?>
          </ul>
        </div>
      </li>
    <?php endif; ?>
    <li class="nav-item">
      <hr>
      <form method="POST" action="<?php echo e(URL::to('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger btn-block"><i class="fa fa-power-off"></i> &nbsp; Logout</button>
      </form>
    </li>
    </ul>
    <hr>
  </nav><?php /**PATH C:\xampp\htdocs\matribhumi\resources\views/layouts/header.blade.php ENDPATH**/ ?>