<!-- partial:partials/_footer.html -->
<footer class="footer">
  <div class="d-sm-flex justify-content-center justify-content-sm-between">
    <span class="text-muted text-right text-sm-right d-block d-sm-inline-block"> Powered By <a href="https://www.bmsnepal.net/" target="_blank">BMS NEPAL</a>. All rights reserved.</span>
  </div>
</footer>
</div>
<!-- container-scroller -->

<!-- plugins:js -->

<!-- endinject -->
<!-- Plugin js for this page-->
<!-- End plugin js for this page-->