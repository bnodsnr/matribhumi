
<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-12">
    <nav aria-label="breadcrumb card-header">
      <ol class="breadcrumb breadcrumb-custom">
        <li class="breadcrumb-item"><a href="<?php echo e(URL :: to('/dashboard')); ?>">ड्यासबोर्ड</a></li>
        <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(URL :: to('/users')); ?>">प्रयोगकर्ता सुची</a></li>
        <li class=" breadcrumb-item active" aria-current="page"><span></span> नया थप्नुहोस</li>
      </ol>
    </nav>
    <form method="post" action="<?php echo e(route('save-user')); ?>" class="sky-form">
      <?php echo csrf_field(); ?>
      <header>प्रयोगकर्ता विवरण भर्नुहोस्</header>
      <fieldset>
        <div class="row">
          <section class="col col-6">
            <label><b>प्रयोगकर्ता नाम<span class="text-danger">*</span></b></label>
            <div class="input">
              <i class="icon-append fa fa-info-circle"></i>
              <input type="text" class="form-control" name="name" placeholder="">
            </div>
            <?php if($errors->has('name')): ?>
            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
            <?php endif; ?>
          </section>
          <section class="col col-6">
            <label><b>प्रयोगकर्ता इमेल</b><span class="text-danger">*</span></label>
            <div class="input">
              <i class="icon-append icon-envelope-alt"></i>
              <input type="email" class="form-control" name="email" placeholder="">
            </div>
            <?php if($errors->has('email')): ?>
            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
          </section>
          <section class="col col-6">
            <label><b>प्रयोगकर्ता फोन नं. </b><span class="text-danger">*</span></label>
            <div class="input">
              <i class="icon-append fa fa-phone"></i>
              <input type="number" class="form-control" name="phone" placeholder="">
            </div>
            <?php if($errors->has('phone')): ?>
            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
            <?php endif; ?>
          </section>

          <section class="col col-6">
            <label><b>प्रयोगकर्ता पद </b><span class="text-danger">*</span></label>
            <div class="input">
              <i class="icon-append fa fa-info-circle"></i>
              <input type="text" class="form-control" name="designation" placeholder="">
            </div>
            <?php if($errors->has('designation')): ?>
            <span class="text-danger"><?php echo e($errors->first('designation')); ?></span>
            <?php endif; ?>
          </section>
        </div>
      </fieldset>
      <fieldset>
        <div class="row">
          <section class="col col-3">
            <label><b>प्रयोगकर्ता भूमिका </b><span class="text-danger">*</span></label>
            <div class="select">
              <select class="form-control" name="role_id">
                <option value=""> --छान्नुहोस्--</option>
                <?php if(!empty($roles)): ?>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>
              <i></i>
            </div>
            <?php if($errors->has('role')): ?>
            <span class="text-danger"><?php echo e($errors->first('role')); ?></span>
            <?php endif; ?>
          </section>
          <section class="col col-3">
            <label><b>प्रयोगकर्ता आइडी</b><span class="text-danger">*</span></label>
            <div class="input">
              <i class="icon-append fa fa-square "></i>
              <input type="text" class="form-control" name="username" placeholder="">
            </div>
            <?php if($errors->has('username')): ?>
            <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
            <?php endif; ?>
          </section>
          <section class="col col-3">
            <label><b>पासवर्ड </b><span class="text-danger">*</span></label>
            <div class="input">
              <i class="icon-append fa fa-key"></i>
              <input type="password" class="form-control" name="password" placeholder="">
            </div>
            <?php if($errors->has('password')): ?>
            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
          </section>

          <!-- <section class="col col-4">
            <label><b>पासवर्ड सुनिस्चित </b><span class="text-danger">*</span></label>
            <div class="input">
              <i class="icon-append fa fa-key"></i>
              <input type="password" class="form-control" name="password" placeholder="">
            </div>
            <?php if($errors->has('password')): ?>
            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
          </section> -->
      </fieldset>
      <footer>
        <button type="submit" class="button">सेभ गर्नुहोस</button>
      </footer>
    </form>
  </div>
</div>
<!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matribhumi\resources\views/auth/register.blade.php ENDPATH**/ ?>