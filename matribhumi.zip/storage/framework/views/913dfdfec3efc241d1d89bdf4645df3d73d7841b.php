
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb breadcrumb-custom">
        <li class="breadcrumb-item"><a href="<?php echo e(URL :: to('/dashboard')); ?>">ड्यासबोर्ड</a></li>
        <li class="breadcrumb-item active" aria-current="page"><span>प्रोयोगकर्ता सुची</span></li>
      </ol>
    </nav>
    <div class="card">

      <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
      </div>
      <?php endif; ?>
      <div class="table-responsive">

      <?php if(auth()->user()->role != 1): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-user')): ?>
      <?php endif; ?>
        <div class="card-title"><a href="<?php echo e(URL :: to('/create')); ?>" class="btn btn-sm btn-dark"><i class="fa fa-plus-circle"></i> नया थप्नुहोस</a></div><br>
        <?php if(auth()->user()->role != 1): ?>
        <?php endif; ?>
        <?php endif; ?>
        <table class="rtable">
          <thead>
            <tr>
              <th>क्र. सं.</th>
              <th>नाम</th>
              <th>इमेल</th>
              <th>फोन नं</th>
              <th>पद </th>
              <th>भूमिका </th>
              <th>शाखा</th>
            </tr>
          </thead>
          <tbody>
            <?php if(!empty($users)): ?>
            <?php $i=1; ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($i++); ?></td>
              <td><?php echo e($user->name); ?></td>
              <td><?php echo e($user->email); ?></td>
              <td><?php echo e($user->phone); ?></td>
              <td><?php echo e($user->designation); ?></td>
              <td><?php echo e($user->bhumika->name); ?></td>
              <?php if(auth()->user()->can('edit-user') || auth()->user()->can('remove-user')): ?>
              <td>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-user')): ?>
                <a href="<?php echo e(route('edit-user', $user->id)); ?>" class="btn btn-sm btn-info btn-sm ">
                  <i class="fa fa-pencil"></i>
                </a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('remove-user')): ?>
                <a href="<?php echo e(route('show-modules', $user->id)); ?>" class="btn btn-sm btn-warning btn-sm ">
                  <i class="fa fa-info-circle"></i>
                </a>
                <?php endif; ?>
              </td>
              <?php endif; ?>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>
<!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matribhumi\resources\views/auth/userlist.blade.php ENDPATH**/ ?>