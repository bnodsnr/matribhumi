<?php

namespace App\Http\Controllers;

use App\Models\GeneralOption;
use App\Models\Category;
use Illuminate\Http\Request;

class GeneralOptionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $menus = Category::where('is_menu', 1)->orderBy('menu_position','asc')->get();
        return view('generaloption.index', compact('menus'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\GeneralOption  $generalOption
     * @return \Illuminate\Http\Response
     */
    public function show(GeneralOption $generalOption)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\GeneralOption  $generalOption
     * @return \Illuminate\Http\Response
     */
    public function edit(GeneralOption $generalOption)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\GeneralOption  $generalOption
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, GeneralOption $generalOption)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\GeneralOption  $generalOption
     * @return \Illuminate\Http\Response
     */
    public function destroy(GeneralOption $generalOption)
    {
        //
    }
}
