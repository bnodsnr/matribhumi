
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb breadcrumb-custom">
        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
        <li class="breadcrumb-item active" aria-current="page"><span>Advertisement List</span></span></li>
      </ol>
    </nav>
    <div class="card">
        <p class="card-description">
        <a class="btn btn-sm btn-dark" href="<?php echo e(route('create-ads')); ?>"><i class="fa fa-plus-circle"></i> Add New</a>
        </p>
      <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
      </div>
      <?php endif; ?>
      <div class="table-responsive">

        <table id="order-listing" class="table dataTable no-footer">
          <thead>
            <tr>
              <th>SN</th>
              <th>Company Name</th>
              <th>Position</th>
              <th>Image</th>
              <th>Publish Date</th>
              <th>Status</th>
              <th>#</th>
            </tr>
          </thead>
          <tbody>
            <?php $i =1; ?> <?php if(!empty($advertisements)): ?>
            <?php $__currentLoopData = $advertisements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertisement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($advertisement->company_name); ?></td>
            <td><label class="badge badge-outline-danger"><?php echo e($advertisement->position); ?></label></td>
            <td><img src="<?php echo e(asset('public/uploads/'.$advertisement->ads_image)); ?>" alt="profile image"></td>
            <td><?php echo e($advertisement->publish_date); ?></td>
            <td><?php if($advertisement->status == 1): ?><label class="badge badge-success">Published</label><?php else: ?> <label class="badge badge-danger">Draft</label><?php endif; ?></td>
            <td><a href="<?php echo e(route('edit-ads', $advertisement->id)); ?>" class="btn btn-info btn-sm ml-2"><i class="fa fa-pencil"></i></a><a href="" class="btn btn-danger btn-sm ml-2"><i class="fa fa-times"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>
<!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matribhumi\resources\views/ads/list.blade.php ENDPATH**/ ?>